.. ONETEP documentation master file, created by
   sphinx-quickstart on Wed Sep 21 09:31:53 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ONETEP's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   starting_with_onetep.rst
   index_ground_state.rst
   index_correlation_constrained.rst
   index_dynamics.rst
   index_transition_states.rst
   index_spectroscopy.rst
   index_population.rst
   index_gpu.rst
   index_qmmm.rst
   index_properties.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

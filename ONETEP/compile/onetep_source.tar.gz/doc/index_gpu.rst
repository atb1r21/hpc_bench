.. ONETEP documentation master file, created by
   sphinx-quickstart on Wed Sep 21 09:31:53 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GPU Accelerated Code
================================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ONETEP_OpenACC.rst
